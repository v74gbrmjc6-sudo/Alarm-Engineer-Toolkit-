ALARM ENGINEER TOOLKIT V7
==========================

This is a standalone mobile-first HTML version.

DEPLOY TO VERCEL:
1. Extract the ZIP.
2. Upload the folder/project to Vercel, or import it as a project.
3. The site entry point is index.html.

IMPORTANT:
- This version includes official manufacturer resource links and generic visual wiring diagrams.
- It intentionally does not embed manufacturer manuals or copyrighted diagrams.
- The live AI feature requires a secure backend. Never put an OpenAI API key in index.html.
- Manufacturer-specific wiring, resistor values, credentials and programming must be checked against the exact panel/device documentation.

Official sources included:
Texecom product downloads: https://www.texe.com/help-and-support/product-support/
Pyronix Enforcer V11 support: https://www.support.pyronix.com/uk/product/enforcer-v11
RISCO LightSYS+: https://riscogroup.com/en/rscm_product/lightsys/
Eaton i-on10: https://www.eaton.com/gb/en-gb/catalog/safety-security-and-emergency-communications/i-on10-panel.html
